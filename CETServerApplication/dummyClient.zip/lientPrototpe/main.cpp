#include <QtCore/QCoreApplication>

#include <stdio.h>
#include <sys/types.h>/* system type definitions */

#include <client.h>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QString address;
    char address1 [16] ;

    Client client;

    cout<<"Enter an IP address or home for default"<<endl;

    //getline(cin,address);
    cin.getline(address1,16);

    address = (QString) address1;

    if (address == "home"){
        cout<<"Connecting to "<<address.toStdString()<<endl;
        client.start("127.0.0.1", 6789);
    }else
    {
        cout<<"Connecting to "<<address.toStdString()<<endl;
        client.start(address, 6789);
    }





    return a.exec();
}
