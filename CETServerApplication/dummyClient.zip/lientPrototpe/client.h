#ifndef CLIENT_H
#define CLIENT_H

#include <QtNetwork>
#include <QtCore>

class Client: public QObject
{
Q_OBJECT
public:
  Client(QObject* parent = 0);
  ~Client();
  void start(QString address, quint16 port);
  //bool chunked;
public slots:
  void startTransfer();
  void readMessage();
private:
  QTcpSocket client;
};


#endif // CLIENT_H
