#include "client.h"
#include "stdio.h"
#include <QHostAddress>
#include <iostream>

using namespace std;

Client::Client(QObject* parent): QObject(parent)
{
  //chunked = true;
  connect(&client, SIGNAL(connected()), this, SLOT(startTransfer()));
  connect(&client,SIGNAL(readyRead()),this,SLOT(readMessage()));
}

Client::~Client()
{
  client.close();
}

void Client::start(QString address, quint16 port)
{
  QHostAddress addr(address);

  //client.connectToHost(addr, port);
  client.connectToHost(addr,port);
}

void Client::startTransfer()
{
    //soem dummy requests
  //client.write("Hello server", 13);

    /*
    //this if represented testing chunkc, didnt work
    if(false){
        client.write("<?xml version = \"1.0\"?>",30);
        client.write("<message>",30);
        client.write("<command>",30);
        client.write("<getIdNumbers>",30);
        client.write("</command>",30);
        client.write("<getIdNumbersRequest",30);
        client.write("<blockSize>",30);
        client.write("10",30);
        client.write("</blockSize>",30);
        client.write("</getIdNumbersRequest",30);
        client.write("</message>",30);
    }else{*/

        client.write("<?xml version=\"1.0\"?><message><command>getIdNumbers</command><getIdNumbersRequest><blockSize>10</blockSize></getIdNumbersRequest></message>",1024);
    //}

}


void Client::readMessage()
{
    char message[1024] = {0};


    client.read(message,client.bytesAvailable());
    cout<<message<<endl;

}

